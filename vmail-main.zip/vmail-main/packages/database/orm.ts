import * as orm from "drizzle-orm";

export default orm;
