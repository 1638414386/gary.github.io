export default {
  // This is the list of languages your application supports
  supportedLngs: [
    "en",
    "zh",
    "fr",
    "ja",
    "hi",
    "de",
    "ko",
    "zh-TW",
    "it",
    "pt",
    "tr",
    "ru",
  ],
  // This is the language you want to use in case
  // if the user language is not in the supportedLngs
  fallbackLng: "en",
  // The default namespace of i18next is "translation", but you can customize it here
  defaultNS: "common",
};
